package appweb.com.dao;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import appweb.com.model.ExamenSangre;

@Stateless
public class ExamenSangreServiceEJB extends AbstractPersistence<ExamenSangre, Long> implements ExamenSangreService{



	//implementar la jpa
	@PersistenceContext
	private EntityManager em;
	
	@Override
	protected EntityManager getEntityManager() {
		return em;
	}
	
	//constructor
	public ExamenSangreServiceEJB() {
		super(ExamenSangre.class);
		// TODO Auto-generated constructor stub
	}

	
}
