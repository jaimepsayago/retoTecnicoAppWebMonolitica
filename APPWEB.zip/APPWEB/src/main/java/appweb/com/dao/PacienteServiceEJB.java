package appweb.com.dao;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import appweb.com.model.Paciente;



@Stateless
public class PacienteServiceEJB extends AbstractPersistence<Paciente, Long> implements PacienteService{



	//implementar la jpa
	@PersistenceContext
	private EntityManager em;
	
	@Override
	protected EntityManager getEntityManager() {
		return em;
	}
	
	//constructor
	public PacienteServiceEJB() {
		super(Paciente.class);
		// TODO Auto-generated constructor stub
	}

}
