package appweb.com.dao;

import java.util.List;

import javax.ejb.Local;

import appweb.com.model.ExamenSangre;


@Local
public interface ExamenSangreService {
	//crud
	public ExamenSangre save(ExamenSangre a);
	public void remove(ExamenSangre a);
	public ExamenSangre find(Long id);
	public ExamenSangre findObject(ExamenSangre id);
	public List<ExamenSangre> findAll();
	

}
