package appweb.com.dao;

import java.util.List;

import javax.ejb.Local;

import appweb.com.model.Paciente;

@Local
public interface PacienteService {
	//crud
	public Paciente save(Paciente a);
	public void remove(Paciente a);
	public Paciente find(Long id);
	public Paciente findObject(Paciente id);
	public List<Paciente> findAll();
	

}
