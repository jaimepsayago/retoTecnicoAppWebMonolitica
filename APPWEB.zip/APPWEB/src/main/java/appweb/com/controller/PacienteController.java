package appweb.com.controller;
/*
 * aqui se integra las distintas capas de la appweb
 * model - dao - controller -  vistas
 */


import java.io.Serializable;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.enterprise.context.RequestScoped;
import javax.faces.event.ActionEvent;
import javax.inject.Inject;
import javax.inject.Named;


import org.primefaces.PrimeFaces;

import appweb.com.dao.ExamenSangreService;
import appweb.com.dao.PacienteService;
import appweb.com.model.ExamenSangre;
import appweb.com.model.Paciente;

@Named
@RequestScoped
public class PacienteController implements Serializable {
	private static final long serialVersionUID = 1L;
	
	//conectar con la capa negocio -  cdi context dependecy inyection
	@Inject
	private PacienteService pacienteService;
	
	@Inject
	private ExamenSangreService examenSangreService;
	
	//objeto de tipo paciente
	private Paciente paciente;
	
	//objeto de tipo examen
	
	private ExamenSangre examenSangre;
	private Long examenNumero;
	private BigDecimal azucar;
		private BigDecimal grasa;
		public BigDecimal getGrasa() {
			return grasa;
		}


		public void setGrasa(BigDecimal grasa) {
			this.grasa = grasa;
		}


		public BigDecimal getOxigeno() {
			return oxigeno;
		}


		public void setOxigeno(BigDecimal oxigeno) {
			this.oxigeno = oxigeno;
		}

		private BigDecimal oxigeno;
		
	//listar los datos del autor
	List<Paciente> list;
	//listar los datos del autor
		List<ExamenSangre> listex;
	
	//otras variables para los otros metodos
	private Paciente selectedPaciente;
	
	
	//constructor
	public PacienteController() {
		if (paciente == null) {
			paciente = new Paciente(); //si no existe el autor recien aqui me instancia el objeto
		}
	}


	public PacienteService getAutorService() {
		return pacienteService;
	}


	public void setAutorService(PacienteService autorService) {
		this.pacienteService = autorService;
	}


	


	public BigDecimal getAzucar() {
		return azucar;
	}


	public void setAzucar(BigDecimal azucar) {
		this.azucar = azucar;
	}


	public Long getExamenNumero() {
		return examenNumero;
	}


	public void setExamenNumero(Long examenNumero) {
		this.examenNumero = examenNumero;
	}


	public List<ExamenSangre> getListex() {
		return listex;
	}


	public void setListex(List<ExamenSangre> listex) {
		this.listex = listex;
	}


	public Paciente getPaciente() {
		return paciente;
	}


	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}


	public List<Paciente> getList() {
		list = pacienteService.findAll();
		return list;
	}


	public void setList(List<Paciente> list) {
		this.list = list;
	}


	public ExamenSangre getExamenSangre() {
		return examenSangre;
	}


	public void setExamenSangre(ExamenSangre examenSangre) {
		this.examenSangre = examenSangre;
	}

	
	//metodos
	





	public Paciente getSelectedPaciente() {
		return selectedPaciente;
	}


	public void setSelectedPaciente(Paciente selectedPaciente) {
		this.selectedPaciente = selectedPaciente;
	}


	//guardar
	public String guardar() {
		
		try {
			System.out.println("service: " + pacienteService); //controlor de datos
			//paciente.addRtExamenSangre(examenSangre);
			
			
			//System.out.println("service: " + paciente.getRtExamenSangre());
			pacienteService.save(paciente);
			
		} catch (Exception e) {
			System.out.println("error" + e.getMessage());
			return "";
		}
		
		return "listarPaciente";
	}
	
		
	//editar
	public void editar() {
		if(selectedPaciente == null) {
			return;
		}
		//buscar datos del autor por id
		Long id = Long.parseLong(selectedPaciente.getId().toString());
		paciente = pacienteService.find(id);
		examenSangre = examenSangreService.find(id);
		//listex = examenSangreService.findAll();
		
		System.out.println("examen sangre: " + examenSangre.getPorcentajeAzucar());
		
	}

	
	
	public void agregar() {
		//Long id = Long.parseLong(selectedPaciente.getId().toString());
		 examenSangre = new ExamenSangre();
		//paciente = pacienteService.find(id);
		examenSangre.setId(examenNumero);
		examenSangre.setPorcentajeAzucar(azucar);
		examenSangre.setPorcentajeGrasa(grasa);
		examenSangre.setPorcentajeOxigeno(oxigeno);
		examenSangre.setRtPaciente(paciente);
		//listex.add(examenSangre);
		//examenSangre.getRtPaciente();
		//examenSangreService.save(examenSangre);
		paciente.addRtExamenSangre(examenSangre);
		//examenSangreService.save(examenSangre);
		System.out.println("examen sangre: " + examenSangre.toString());
	}
	
	
	//eliminar
	public String remover(ActionEvent e) {
		try {
			paciente = new Paciente();
			String i= e.getComponent().getAttributes().get("itemEliminar").toString(); //obtenemos el parametro desde el dtatable
			Long dato = Long.parseLong(i);
			paciente.setId(dato);
			pacienteService.remove(paciente);
			
			
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			return "";
		}
		return "listarPaciente";
	}
	
	//
	 public void view() {
	        Map<String, Object> options = new HashMap<>();
	        options.put("resizable", false);
	        PrimeFaces.current().dialog().openDynamic("agregarExamen", options, null);
	    }


}
