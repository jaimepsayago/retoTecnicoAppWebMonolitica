package appweb.com.model;


import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the rt_examen_sangre database table.
 * 
 */
@Entity
@Table(name="rt_examen_sangre")
@NamedQuery(name="ExamenSangre.findAll", query="SELECT e FROM ExamenSangre e")
public class ExamenSangre implements AbstractEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;

	@Temporal(TemporalType.DATE)
	@Column(name="\"created_ExamenSangre\"")
	private Date created_ExamenSangre;

	private String descripcion;

	@Temporal(TemporalType.DATE)
	private Date fecha;

	@Column(name="porcentaje_azucar")
	private BigDecimal porcentajeAzucar;

	@Column(name="porcentaje_grasa")
	private BigDecimal porcentajeGrasa;

	@Column(name="porcentaje_oxigeno")
	private BigDecimal porcentajeOxigeno;

	@Temporal(TemporalType.DATE)
	@Column(name="\"updated_ExamenSangre\"")
	private Date updated_ExamenSangre;

	//bi-directional many-to-one association to Paciente
	@ManyToOne
	@JoinColumn(name="id_paciente")
	private Paciente rtPaciente;

	public ExamenSangre() {
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getCreated_ExamenSangre() {
		return this.created_ExamenSangre;
	}

	public void setCreated_ExamenSangre(Date created_ExamenSangre) {
		this.created_ExamenSangre = created_ExamenSangre;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Date getFecha() {
		return this.fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public BigDecimal getPorcentajeAzucar() {
		return this.porcentajeAzucar;
	}

	public void setPorcentajeAzucar(BigDecimal porcentajeAzucar) {
		this.porcentajeAzucar = porcentajeAzucar;
	}

	public BigDecimal getPorcentajeGrasa() {
		return this.porcentajeGrasa;
	}

	public void setPorcentajeGrasa(BigDecimal porcentajeGrasa) {
		this.porcentajeGrasa = porcentajeGrasa;
	}

	public BigDecimal getPorcentajeOxigeno() {
		return this.porcentajeOxigeno;
	}

	public void setPorcentajeOxigeno(BigDecimal porcentajeOxigeno) {
		this.porcentajeOxigeno = porcentajeOxigeno;
	}

	public Date getUpdated_ExamenSangre() {
		return this.updated_ExamenSangre;
	}

	public void setUpdated_ExamenSangre(Date updated_ExamenSangre) {
		this.updated_ExamenSangre = updated_ExamenSangre;
	}

	public Paciente getRtPaciente() {
		return this.rtPaciente;
	}

	public void setRtPaciente(Paciente rtPaciente) {
		this.rtPaciente = rtPaciente;
	}

}