package appweb.com.model;


import java.sql.Timestamp;
import java.time.Instant;

import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the rt_paciente database table.
 * 
 */
@Entity
@Table(name="rt_paciente")
@NamedQuery(name="Paciente.findAll", query="SELECT p FROM Paciente p")
public class Paciente implements AbstractEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;

	@Column(name="nombre_paciente")
	private String nombrePaciente;
	
	@Column(name="apellido_paciente")
	 private String apellidoPaciente;
	
	@Column(name="identificacion_paciente")
	 private String identificacionPaciente;
	
	@Column(name="direccion_paciente")
	 private String direccionPaciente;
	
	@Column(name="telefono_paciente")
	 private String telefonoPaciente;
	
	@Column(name="email_paciente")
	 private String emailPaciente;
	
	@Column(name = "created_Paciente")
	private Timestamp created;
    @Column(name = "updated_Paciente")
	private Timestamp updated;

	//bi-directional many-to-one association to ExamenSangre
	@OneToMany(mappedBy="rtPaciente",cascade=CascadeType.ALL, fetch= FetchType.EAGER)
	private List<ExamenSangre> rtExamenSangre;

	public Paciente() {
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombrePaciente() {
		return this.nombrePaciente;
	}

	public void setNombrePaciente(String nombrePaciente) {
		this.nombrePaciente = nombrePaciente;
	}
	
	

	public String getApellidoPaciente() {
		return apellidoPaciente;
	}

	public void setApellidoPaciente(String apellidoPaciente) {
		this.apellidoPaciente = apellidoPaciente;
	}

	public String getIdentificacionPaciente() {
		return identificacionPaciente;
	}

	public void setIdentificacionPaciente(String identificacionPaciente) {
		this.identificacionPaciente = identificacionPaciente;
	}

	public String getDireccionPaciente() {
		return direccionPaciente;
	}

	public void setDireccionPaciente(String direccionPaciente) {
		this.direccionPaciente = direccionPaciente;
	}

	public String getTelefonoPaciente() {
		return telefonoPaciente;
	}

	public void setTelefonoPaciente(String telefonoPaciente) {
		this.telefonoPaciente = telefonoPaciente;
	}

	public String getEmailPaciente() {
		return emailPaciente;
	}

	public void setEmailPaciente(String emailPaciente) {
		this.emailPaciente = emailPaciente;
	}

	public List<ExamenSangre> getRtExamenSangre() {
		return this.rtExamenSangre;
	}

	public void setRtExamenSangre(List<ExamenSangre> rtExamenSangre) {
		this.rtExamenSangre = rtExamenSangre;
	}

	 public Instant getCreated() {
	        return created.toInstant();
	    }

	    public Instant getUpdated() {
	        return updated.toInstant();
	    }
	    
	public ExamenSangre addRtExamenSangre(ExamenSangre rtExamenSangre) {
		getRtExamenSangre().add(rtExamenSangre);
		rtExamenSangre.setRtPaciente(this);
		System.out.println("paciente orm: " + rtExamenSangre.toString());
		return rtExamenSangre;
	}

	public ExamenSangre removeRtExamenSangre(ExamenSangre rtExamenSangre) {
		getRtExamenSangre().remove(rtExamenSangre);
		rtExamenSangre.setRtPaciente(null);

		return rtExamenSangre;
	}

}